function pow(base, exp) {
  // From: http://phpjs.org/functions
  // +   original by: Onno Marsman
  // *     example 1: pow(8723321.4, 7);
  // *     returns 1: 3.8439091680778995e+48
  return Math.pow(base, exp);
}
