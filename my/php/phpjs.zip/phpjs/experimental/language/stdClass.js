function stdClass() {
  // http://kevin.vanzonneveld.net
  // +   original by: Brett Zamir (http://brett-zamir.me)
  // *     example 1: var a = new stdClass();
  // *     returns 1: {}

  // No need to return anything; this is PHP's base class
}
