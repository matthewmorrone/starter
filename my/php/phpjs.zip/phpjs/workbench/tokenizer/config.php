<?php
//$file = 'test.php';
//$file = 'test2.php';
//$file = 'test3.php';
$file = 'simple.php';
$file = 'simple2.php';
$file = 'heredoc.php';

?>