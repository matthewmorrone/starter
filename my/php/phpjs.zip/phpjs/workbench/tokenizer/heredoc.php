<?php
if (1)
$insert = 5;
elseif (2) {}
$a = <<<STH

Test$insert
STH;
?>