using System;
using System.Collections.Generic;

namespace jQuerySheet
{
	public class SpreadsheetsDictionary : Dictionary<int, SpreadsheetDictionary>
	{
	}
}

