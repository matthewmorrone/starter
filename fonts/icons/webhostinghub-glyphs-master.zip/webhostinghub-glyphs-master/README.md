#WebHostingHub Glyphs
====================
WebHostingHub Glyphs is the most comprehensive set of glyph icons available as font currently containing 2075 glyphs (and counting). The goal is to be fully compatible with Bootstrap and other frameworks and CMSs. It will be constantly updated so if you have ideas for new icons, do let us know.

The full suite of pictographic icons, examples, and documentation ad well as icons in PNG format can be found at:
http://www.webhostinghub.com/glyphs/


##License
- The WebHostingHub Glyphs font is licensed under the SIL Open Font License - http://scripts.sil.org/OFL
- WebHostingHub Glyphs CSS, LESS, and SASS files are licensed under the MIT License - http://opensource.org/licenses/mit-license.html
- The WebHostingHub Glyphs pictograms are licensed under the CC BY 3.0 License - http://creativecommons.org/licenses/by/3.0/
- Attribution is much appreciated: "WebHostingHub Glyphs - http://www.webhostinghub.com/glyphs/"

##Contact
- Email: whhglyphs@gmail.com
- Twitter: http://twitter.com/whhglyphs

##Thanks
This project would not be possible without support from http://www.WebHostingHub.com

